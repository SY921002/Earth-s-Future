library(ggplot2)
library(reshape2) 


b<-read.csv("5th-50th percentiles importance.csv")

#####give name to indices and order them
b$indices<-NA
b[which(b$X=="DH_DF_intensity_sum"),]$indices<-"DET"
b[which(b$X=="non_DH_DF_drought_paw_intensity_sum"),]$indices<-"Drought"
b[which(b$X=="non_DH_DF_heat_paw_intensity_sum"),]$indices<-"Heat"
b[which(b$X=="non_DH_DF_frost_paw_intensity_sum"),]$indices<-"Frost"

b$percentile<-NA
b[which(b$region=="0.05"),]$percentile<-"5th"
b[which(b$region=="0.1"),]$percentile<-"10th"
b[which(b$region=="0.15"),]$percentile<-"15th"
b[which(b$region=="0.2"),]$percentile<-"20th"
b[which(b$region=="0.25"),]$percentile<-"25th"
b[which(b$region=="0.3"),]$percentile<-"30th"
b[which(b$region=="0.35"),]$percentile<-"35th"
b[which(b$region=="0.4"),]$percentile<-"40th"
b[which(b$region=="0.45"),]$percentile<-"45th"
b[which(b$region=="0.5"),]$percentile<-"50th"

b$order<-NA
b[which(b$X=="DH_DF_intensity_sum"),]$order<-"4"
b[which(b$X=="non_DH_DF_drought_paw_intensity_sum"),]$order<-"3"
b[which(b$X=="non_DH_DF_heat_paw_intensity_sum"),]$order<-"2"
b[which(b$X=="non_DH_DF_frost_paw_intensity_sum"),]$order<-"1"
#####give name to indices and order them

#####order 12 subregions
b$id<-NA
b[which(b$region=="0.05"),]$id<-"0"
b[which(b$region=="0.1"),]$id<-"1"
b[which(b$region=="0.15"),]$id<-"2"
b[which(b$region=="0.2"),]$id<-"3"
b[which(b$region=="0.25"),]$id<-"4"
b[which(b$region=="0.3"),]$id<-"5"
b[which(b$region=="0.35"),]$id<-"6"
b[which(b$region=="0.4"),]$id<-"7"
b[which(b$region=="0.45"),]$id<-"8"
b[which(b$region=="0.5"),]$id<-"9"
#####order 12 subregions

########create labels for each subregion and order them
x_label<-c("5th","10th","15th","20th","25th","30th","35th","40th","45th","50th")
names(x_label)<-c("1","2","3","4","5","6","7","8","9","10")
########create labels for each subregion and order them


png(file = "name for figure 6.png", bg = "white", type = c("cairo"),width=3300, height=2300, res=600)#output figure 6
########code for plot
ggplot(b, aes(fill=order, y=value, x=id)) + 
  geom_bar(position="fill", stat="identity", width = 0.48)+
  scale_fill_manual(values = c("#6baed6","#fb6a4a","#fe9929","#74c476"),labels = c("FI","HI","DI","DETI"))+
  #scale_fill_manual(values = c("#9ecae1","#fc9272","#fec44f","#a1d99b"),labels = c("FI","HI","DI","DETI"))+
  labs(title="", x="Percentiles of yield anomalies for selecting low-yield years", y = "Relative importance (%)")+
  scale_y_continuous(labels = scales::percent_format(accuracy = 1))+
  scale_x_discrete(labels=c("0" = bquote(5^th), "1" = bquote(10^th),
                            "2" = bquote(15^th), "3" = bquote(20^th),
                            "4" = bquote(25^th), "5" = bquote(30^th),
                            "6" = bquote(35^th), "7" = bquote(40^th),
                            "8" = bquote(45^th), "9" = bquote(50^th)))+
  
  theme(
    
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=9,color = 'black'),
    axis.title=element_text(size=9),
    axis.line=element_line(size=0.002,colour = 'black'),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=0.7,color = "black"),
    legend.position = 'top',
    legend.key.width=unit(0.5, "cm"),
    legend.key.height=unit(0.5, "cm"),
    legend.text=element_text(size=9),
    text = element_text(family = "Times New Roman",size=9),
    legend.title=element_blank())
########code for plot
dev.off()#output figure 6


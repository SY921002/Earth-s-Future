library(ggplot2)
library("trend")
library(data.table)
library(purrr)
library(dplyr)
library("plyr")
library("readr")

########import and organise data for plot
I_data<-read.csv("yield anomalies and DETI.csv")

x_label<-c("QLDW","QLDE","NSWN","NSWC","NSWR","VICC","VICM","VICW","SAMu","SAEy","WACe","WANo")
names(x_label)<-c("1","2","3","4","5","6","7","8","9","10","11","12")

colnames(I_data)<-c("year","yield_anomalies","wheat_yield","DET","region","mean_DET","sd_DET","mk_DET","mk_p_DET","ID","Number")
########import and organise data for plot


png(file = "name for figure 3.png", bg = "white", type = c("cairo"), width=5300, height=3500, res=600)#####output figure 3

########code for plot

ggplot(I_data, aes(x=year)) +
  geom_bar(aes(y=(DET), fill="DETI"),stat="identity",color="white")+
  geom_line(aes(y=(mean_DET), color="Mean DETI",linetype = "Mean DETI"), size=0.5) + 
  geom_line(aes(y=(yield_anomalies+3)/6, color="Yield anomaly",linetype = "Yield anomaly"), size=0.5) +
  scale_linetype_manual(name = "",labels = c("Mean DETI","Yield anomaly"),values=c(3,1))+
  scale_fill_manual(name = "", values = c("DETI" = "#a1d99b")) +
  scale_color_manual(name = "", values = c("Mean DETI" = "#74c476","Yield anomaly" = "#525252")) +
  geom_text(data=I_data, aes(x= -Inf, y=Inf, label=Number), 
            size = 3.3,
            hjust = -0.5,
            vjust = 1.4,
            inherit.aes = FALSE,family = "Times New Roman")+
  scale_y_continuous(
    limits = c(0, 1), 
    breaks = seq(0, 1, 0.25), 
    expand = c(0.025, 0),
    name = "DETI",
    sec.axis = sec_axis(~.*coeff-3, name="Wheat yield anomaly (t/ha)")
  )+ facet_wrap(. ~ ID,labeller = labeller( ID = x_label),ncol=4)+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.2, linetype="solid"),
    strip.text = element_text(size =9,margin = margin(0.1,0,0.1,0, "cm")),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=9,color = 'black'),
    axis.title=element_text(size=9),
    axis.line=element_line(size=0.002,colour = 'black'),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=0.7,color = "black"),
    legend.position = 'top',
    legend.key = element_rect(fill = "white"),
    legend.text=element_text(size=9),
    text = element_text(family = "Times New Roman",size=9),
    legend.title=element_text(colour="white", size = 9, face='bold'))
########code for plot


dev.off()#####output figure 3


library(stringr)
library(ggplot2)
library(reshape2)
library(dplyr)
library(scales)
library(facetscales)
library("ggpubr")

##############import and organise data
dd<-read.csv("all region MLR results.csv")

dd$with<-"DI+HI+FI+DETI"#change the colname for data then it can be showed in facet for each plot in figure 5
dd$without<-"DI+HI+FI"#change the colname for data then it can be showed in facet for each plot in figure 5

dd$divide<-NA
dd[which(dd$yield.anomalies>0),]$divide<-"Positive yield anomalies"#divide data into positive and negative parts
dd[which(dd$yield.anomalies<0),]$divide<-"Negative yield anomalies"#divide data into positive and negative parts
##############import and organise data

########code for plot
p1<-ggplot(dd) +
  geom_point(aes(y=yield.anomalies,x=predict_with,color= as.factor(divide)),size=1.2,shape=21,stroke =1.6) +
  scale_color_manual(values = c("Positive yield anomalies" = "#6baed6", "Negative yield anomalies" = "#fe9929")) +
  geom_abline(intercept=0,size=1.1,color = "#4d4d4d", slope=1) +
  geom_vline(xintercept = 0, linetype="dotted", 
             color = "#878787", size=1.5)+
  geom_hline(yintercept = 0, linetype="dotted", 
             color = "#878787", size=1.5)+
  facet_grid(. ~ with) +
  xlim(-2.5,2.5)+
  ylim(-2.5,2.5)+
  labs(x='MLR estimated yield anomaly (t/ha)', y='Actual wheat yield anomaly (t/ha)')+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.6, linetype="solid"),
    strip.placement.y = "outside",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=22,color = "black"),
    axis.title=element_text(size=22),
    axis.ticks.length=unit(.20, "cm"),
    axis.ticks.x=element_line(colour = "black",size = 0.8),
    axis.ticks.y=element_line(colour = "black",size = 0.8),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=1.6,color = "black"),
    legend.position = 'top',
    legend.direction = "vertical",
    legend.text=element_text(size=22),
    legend.key.size = unit(0.9, 'cm'),
    text = element_text(family = "Times New Roman",size=22),
    legend.title=element_blank())



p2<-ggplot(dd) +
  geom_point(aes(y=yield.anomalies,x=predict_without,color= as.factor(divide)),size=1.2,shape=21,stroke =1.6) +
  scale_color_manual(values = c("Positive yield anomalies" = "#6baed6", "Negative yield anomalies" = "#fe9929")) +
  geom_abline(intercept=0,size=1.1,color = "#4d4d4d", slope=1) +
  geom_vline(xintercept = 0, linetype="dotted", 
             color = "#878787", size=1.5)+
  geom_hline(yintercept = 0, linetype="dotted", 
             color = "#878787", size=1.5)+
  facet_grid(. ~ without) +
  xlim(-2.5,2.5)+
  ylim(-2.5,2.5)+
  labs(x='MLR estimated yield anomaly (t/ha)', y='Actual wheat yield anomaly (t/ha)')+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.6, linetype="solid"),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=22,color = "black"),
    axis.title=element_text(size=22),
    axis.ticks.length=unit(.20, "cm"),
    axis.ticks.x=element_line(colour = "black",size = 0.8),
    axis.ticks.y=element_line(colour = "black",size = 0.8),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=1.6,color = "black"),
    legend.position = 'top',
    legend.direction = "vertical",
    legend.text=element_text(size=22),
    legend.key.size = unit(0.9, 'cm'),
    text = element_text(family = "Times New Roman",size=22),
    legend.title=element_blank())
########code for plot

###########################
##############import and organise data
dda<-read.csv("positive and negative yield anomalies results.csv")

dda_p<-dda[which(dda$variables=="Positive"),]#select data corresponding to positive yield anomalies 

##############import and organise data

group_levels <- c("without_DET", "with_DET")#Sets the Levels of the Factor
dda_p$type <- factor(dda_p$type, levels = group_levels)#Converts the type Column to a Factor

#create label to show on x axis
x_label<-c("Positive")
names(x_label)<-c("1")
#create label to show on x axis

########code for plot
p3<-ggplot(dda_p, aes(fill=type, y=R2, x=variables)) + 
  geom_bar(position="dodge", stat="identity",width = 0.5)+
  scale_fill_manual(values=c("#a6cee3","#1f78b4"), labels = c("Without DETI", "With DETI"))+
  ylab(bquote(R^2))+
  xlab("")+
  ylim(0,0.6)+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.3, linetype="solid"),
    strip.placement.y = "outside",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=22,color = "black"),
    axis.title=element_text(size=22),
    axis.ticks.length=unit(.20, "cm"),
    axis.ticks.x=element_line(colour = "black",size = 0.8),
    axis.ticks.y=element_line(colour = "black",size = 0.8),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=1.6,color = "black"),
    legend.position = 'top',
    legend.direction = "vertical",
    legend.text=element_text(size=22),
    legend.key.size = unit(0.9, 'cm'),
    text = element_text(family = "Times New Roman",size=22),
    legend.title=element_blank())
########code for plot

#######this plot is similar to the above plot p3, refer to its comments
dda_n<-dda[which(dda$variables=="Negative"),]

group_levels <- c("without_DET", "with_DET")

dda_n$type <- factor(dda_p$type, levels = group_levels)

p4<-ggplot(dda_n, aes(fill=type, y=R2, x=variables)) + 
  geom_bar(position="dodge", stat="identity",width = 0.5)+
  scale_fill_manual(values=c("#fdbf6f","#ff7f00"), labels = c("Without DETI", "With DETI"))+
  ylab(bquote(R^2))+
  xlab("")+
  ylim(0,0.6)+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.3, linetype="solid"),
    strip.placement.y = "outside",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=22,color = "black"),
    axis.title=element_text(size=22),
    axis.ticks.length=unit(.20, "cm"),
    axis.ticks.x=element_line(colour = "black",size = 0.8),
    axis.ticks.y=element_line(colour = "black",size = 0.8),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=1.6,color = "black"),
    legend.position = 'top',
    legend.direction = "vertical",
    legend.text=element_text(size=22),
    legend.key.size = unit(0.9, 'cm'),
    text = element_text(family = "Times New Roman",size=22),
    legend.title=element_blank())

#combine p3 and p4
p5<-ggarrange(p3,p4,
          labels = c("","",""),nrow = 2)
#combine p3 and p4
###############################
library(reshape2)
library(ggplot2)

I_data<-read.csv("12 subregion R2 with and without DET.csv")##############import data

#####order 12 subregions
I_data$ID<-NA
I_data[which(I_data$region=="QLDW"),]$ID<-1
I_data[which(I_data$region=="QLDE"),]$ID<-2
I_data[which(I_data$region=="NSWN"),]$ID<-3
I_data[which(I_data$region=="NSWC"),]$ID<-4
I_data[which(I_data$region=="NSWR"),]$ID<-5
I_data[which(I_data$region=="VICC"),]$ID<-6
I_data[which(I_data$region=="VICM"),]$ID<-7
I_data[which(I_data$region=="VICW"),]$ID<-8
I_data[which(I_data$region=="SAMu"),]$ID<-9
I_data[which(I_data$region=="SAEy"),]$ID<-10
I_data[which(I_data$region=="WACe"),]$ID<-11
I_data[which(I_data$region=="WANo"),]$ID<-12
I_data[which(I_data$region=="Whole crop belt"),]$ID<-13
#####order 12 subregions


#####order the bars in showing on the plot
I_data$order<-NA

I_data[which(I_data$type=="with_DET"),]$order<-"B"
I_data[which(I_data$type=="without_DET"),]$order<-"A"
#####order the bars in showing on the plot


I_data$index<-"R2"#name the data

########create labels for each subregion and order them
x_label<-c("QLDW","QLDE","NSWN","NSWC","NSWR","VICC","VICM","VICW","SAMu","SAEy","WACe","WANo","All Regions")
names(x_label)<-c("1","2","3","4","5","6","7","8","9","10","11","12")
########create labels for each subregion and order them

########code for plot
p6<-ggplot(I_data, aes(fill=order, y=value, x=ID)) + 
  geom_bar(position="dodge", stat="identity",width = 0.5)+
  scale_x_discrete(limits=x_label)+
  scale_fill_manual(values=c("#a1d99b","#fb9a99"), labels = c("Without DETI", "With DETI"))+
  ylab(bquote(R^2))+
  xlab("")+
  ylim(0,1)+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.3, linetype="solid"),
    strip.placement.y = "outside",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=22,color = "black"),
    axis.title=element_text(size=22),
    axis.ticks.length=unit(.20, "cm"),
    axis.ticks.x=element_line(colour = "black",size = 0.8),
    axis.ticks.y=element_line(colour = "black",size = 0.8),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=1.6,color = "black"),
    legend.position = 'top',
    legend.text=element_text(size=22),
    legend.key.size = unit(0.9, 'cm'),
    text = element_text(family = "Times New Roman",size=22),
    legend.title=element_blank())
########code for plot

#####################


library(reshape2)
library(ggplot2)

b<-read.csv("12 subregions importance.csv")

#####give name to indices and order them
b$indices<-NA
b[which(b$X=="DH_DF_intensity_sum"),]$indices<-"DET"
b[which(b$X=="non_DH_DF_drought_paw_intensity_sum"),]$indices<-"Drought"
b[which(b$X=="non_DH_DF_heat_paw_intensity_sum"),]$indices<-"Heat"
b[which(b$X=="non_DH_DF_frost_paw_intensity_sum"),]$indices<-"Frost"


b$order<-NA
b[which(b$X=="DH_DF_intensity_sum"),]$order<-"4"
b[which(b$X=="non_DH_DF_drought_paw_intensity_sum"),]$order<-"3"
b[which(b$X=="non_DH_DF_heat_paw_intensity_sum"),]$order<-"2"
b[which(b$X=="non_DH_DF_frost_paw_intensity_sum"),]$order<-"1"
#####give name to indices and order them

#####order 12 subregions
b$id<-NA
b[which(b$region=="QLDW"),]$id<-1
b[which(b$region=="QLDE"),]$id<-2
b[which(b$region=="NSWN"),]$id<-3
b[which(b$region=="NSWC"),]$id<-4
b[which(b$region=="NSWR"),]$id<-5
b[which(b$region=="VICC"),]$id<-6
b[which(b$region=="VICM"),]$id<-7
b[which(b$region=="VICW"),]$id<-8
b[which(b$region=="SAMu"),]$id<-9
b[which(b$region=="SAEy"),]$id<-10
b[which(b$region=="WACe"),]$id<-11
b[which(b$region=="WANo"),]$id<-12
#####order 12 subregions

########create labels for each subregion and order them
x_label<-c("QLDW","QLDE","NSWN","NSWC","NSWR","VICC","VICM","VICW","SAMu","SAEy","WACe","WANo")
names(x_label)<-c("1","2","3","4","5","6","7","8","9","10","11","12")
########create labels for each subregion and order them

########code for plot
p7<-ggplot(b, aes(fill=order, y=value, x=id)) + 
  geom_bar(position="fill", stat="identity", width = 0.48)+
  scale_fill_manual(values = c("#6baed6","#fb6a4a","#fe9929","#74c476"),labels = c("FI","HI","DI","DETI"))+
  labs(title="", x="", y = "Relative importance (%)")+
  scale_y_continuous(labels = scales::percent_format(accuracy = 1))+
  scale_x_discrete(limits=x_label)+
  theme(
    strip.background = element_rect(color="black", fill="#999999", size=0.3, linetype="solid"),
    strip.placement.y = "outside",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text=element_text(size=22,color = "black"),
    axis.title=element_text(size=22),
    axis.ticks.length=unit(.20, "cm"),
    axis.ticks.x=element_line(colour = "black",size = 0.8),
    axis.ticks.y=element_line(colour = "black",size = 0.8),
    panel.background = element_rect(colour="white", fill=NA),
    panel.border = element_rect(fill = NA,size=1.6,color = "black"),
    legend.position = 'top',
    legend.text=element_text(size=22),
    legend.key.size = unit(0.9, 'cm'),
    text = element_text(family = "Times New Roman",size=22),
    legend.title=element_blank())
########code for plot

######combine and arrange plots displayed in figure 5
 p8<-ggarrange(p2,p1,
               labels = c("",""),common.legend = TRUE,legend = "top")

 p9 <- ggarrange(p8,p5,
                            widths = c(4, 1), 
                            ncol = 2) 
 ######combine and arrange plots displayed in figure 5

png(file = "name for figure 5.png", bg = "white", type = c("cairo"), width=10000, height=13000, res=600)#output figure 5

######combine and arrange plots displayed in figure 5
ggarrange(p9,p6,p7,
          labels = c("","",""),nrow = 3)
######combine and arrange plots displayed in figure 5

dev.off()#output figure 5


library(reshape)
library(ggplot2)
library("trend")
library(data.table)
library(purrr)
library(dplyr)
library("plyr")
library("readr")


########import and organise data for plot
I_data<-read.csv("mean and sd yield drought, heat, and frost.csv")

J_data<-melt(I_data[,c(1,2,3,4,5,6,7,8,18,19)],id = c("year","name","ID","Number"))
J_1<-J_data[1:1152,]
J_2<-J_data[1153:2304,]

X_data<-cbind(J_1,J_2)

colnames(X_data)<-c("year","name","ID","Number","variable","value","year_mean","name_mean","ID_mean","Number_mean","variable_mean","value_mean")
########import and organise data for plot


########create label for 12 subregions
x_label<-c("QLDW","QLDE","NSWN","NSWC","NSWR","VICC","VICM","VICW","SAMu","SAEy","WACe","WANo")
names(x_label)<-c("1","2","3","4","5","6","7","8","9","10","11","12")
########create label for 12 subregions

png(file = "name for figure 2.png", bg = "white", type = c("cairo"), width=5300, height=3500, res=600)#####output figure 2

########code for plot

ggplot(X_data, aes(x=year)) +
  
  geom_line(aes(y=value,color = variable,linetype=variable),size=0.5) + 
  geom_line(aes(y=value_mean,color = variable_mean,linetype=variable_mean),size=0.5) + 
  scale_linetype_manual(name = "",breaks =c("drought","heat","frost","mean_drought","mean_heat","mean_frost"),labels = c("DI","HI","FI","Mean DI","Mean HI","Mean FI"),values=c(1,1,1,3,3,3),guide = guide_legend(nrow = 2,byrow = T))+
  scale_color_manual(name = "",breaks =c("drought","heat","frost","mean_drought","mean_heat","mean_frost"),labels = c("DI","HI","FI","Mean DI","Mean HI","Mean FI"),values=c("#ff7f00","#e31a1c","#1f78b4","#ff7f00","#e31a1c","#1f78b4"),guide = guide_legend(nrow = 2,byrow = T))+
  geom_text(data=I_data, aes(x= -Inf, y=Inf, label=Number), 
            size = 3.3,
            hjust = -0.5,
            vjust = 1.4,
            inherit.aes = FALSE,family = "Times New Roman")+
  
  scale_y_continuous(
    limits = c(0, 0.8), 
    breaks = seq(0, 0.8, 0.2), 
    expand = c(0.025, 0),
    # Features of the first axis
    name = "Intensity"
  )+ facet_wrap(. ~ ID,labeller = labeller( ID = x_label),ncol=4)+
   theme(
     strip.background = element_rect(color="black", fill="#999999", size=0.2, linetype="solid"),
     strip.text = element_text(size =9,margin = margin(0.1,0,0.1,0, "cm")),
     panel.grid.major = element_blank(),
     panel.grid.minor = element_blank(),
     axis.text=element_text(size=9,color = 'black'),
     axis.title=element_text(size=9),
     axis.line=element_line(size=0.002,colour = 'black'),
     panel.background = element_rect(colour="white", fill=NA),
     panel.border = element_rect(fill = NA,size=0.7,color = "black"),
     legend.position = 'top',
     legend.direction = "horizontal",
     legend.box = "horizontal",
     legend.text=element_text(size=9),
     legend.key = element_rect(fill = "white"),
     text = element_text(family = "Times New Roman",size=9))
########code for plot

dev.off()#####output figure 2


